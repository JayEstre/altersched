import { createClient } from '@/lib/supabase/server'
import { requireRole } from '@/lib/auth/require-role'
import { PageHead, Empty, Badge } from '@/components/ui'
import { approveUser, rejectUser, suspendUser } from './actions'
import { promoteToDepartmentScheduler, demoteSchedulerToFaculty } from './scheduler-actions'

type UserRow = {
  id: string
  email: string | null
  full_name: string | null
  role: 'faculty' | 'department_scheduler'
  account_status: 'pending' | 'approved' | 'rejected' | 'suspended' | 'inactive'
  created_at: string
}

function tone(status: UserRow['account_status']) {
  if (status === 'approved') return 'success' as const
  if (status === 'pending') return 'warning' as const
  if (status === 'rejected' || status === 'suspended') return 'danger' as const
  return 'info' as const
}

export default async function AdminUsersPage({
  searchParams,
}: {
  searchParams?: Promise<{ status?: string; error?: string; success?: string }>
}) {
  await requireRole(['super_admin'])
  const supabase = await createClient()
  const params = searchParams ? await searchParams : {}

  let query = supabase
    .from('profiles')
    .select('id,email,full_name,role,account_status,created_at')
    .in('role', ['faculty', 'department_scheduler'])
    .order('created_at', { ascending: false })

  if (params.status) query = query.eq('account_status', params.status)

  const { data, error } = await query
  const users = (data ?? []) as UserRow[]
  const pending = users.filter((user) => user.account_status === 'pending').length
  const approved = users.filter((user) => user.account_status === 'approved').length
  const schedulers = users.filter((user) => user.role === 'department_scheduler' && user.account_status === 'approved').length

  return (
    <>
      <PageHead
        eyebrow="PEOPLE"
        title="Instructor Approvals"
        description="Review Instructor registrations and manage Department Scheduler access. Student accounts are not part of the current AlterSched scope."
      />

      {params.error ? <div className="form-alert error">Unable to complete the requested account action: {params.error}.</div> : null}
      {params.success ? <div className="form-alert success">Account action completed successfully.</div> : null}
      {error ? <div className="form-alert error">Unable to load Instructor accounts.</div> : null}

      <div className="stats-grid">
        <div className="stat"><span>Pending</span><strong>{pending}</strong><small>Awaiting approval</small></div>
        <div className="stat"><span>Approved</span><strong>{approved}</strong><small>Approved Instructor accounts</small></div>
        <div className="stat"><span>Schedulers</span><strong>{schedulers}</strong><small>Approved Department Schedulers</small></div>
      </div>

      <section className="panel">
        <div className="panel-header">
          <div><h3>Instructor accounts</h3><p>Only Faculty/Instructor and Department Scheduler accounts are managed here.</p></div>
        </div>

        {users.length === 0 ? <Empty text="No Instructor accounts found." /> : (
          <div className="table-wrap">
            <table className="data-table">
              <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id}>
                    <td><strong>{user.full_name || 'Unnamed Instructor'}</strong></td>
                    <td>{user.email || '—'}</td>
                    <td>{user.role === 'department_scheduler' ? 'Department Scheduler' : 'Faculty / Instructor'}</td>
                    <td><Badge tone={tone(user.account_status)}>{user.account_status}</Badge></td>
                    <td>
                      <div className="inline-actions">
                        {user.account_status === 'pending' ? <>
                          <form action={approveUser}><input type="hidden" name="profile_id" value={user.id}/><button className="btn btn-primary" type="submit">Approve</button></form>
                          <form action={rejectUser}><input type="hidden" name="profile_id" value={user.id}/><button className="btn btn-outline" type="submit">Reject</button></form>
                        </> : null}
                        {user.account_status === 'approved' ? <form action={suspendUser}><input type="hidden" name="profile_id" value={user.id}/><button className="btn btn-outline" type="submit">Suspend</button></form> : null}
                        {user.account_status === 'approved' && user.role === 'faculty' ? <form action={promoteToDepartmentScheduler}><input type="hidden" name="profile_id" value={user.id}/><button className="btn btn-outline" type="submit">Make Scheduler</button></form> : null}
                        {user.account_status === 'approved' && user.role === 'department_scheduler' ? <form action={demoteSchedulerToFaculty}><input type="hidden" name="profile_id" value={user.id}/><button className="btn btn-outline" type="submit">Make Faculty</button></form> : null}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </>
  )
}
