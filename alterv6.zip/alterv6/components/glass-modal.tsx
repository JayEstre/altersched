
'use client'

import {
  useId,
  useRef,
  type MouseEvent,
  type ReactNode,
} from 'react'

type GlassModalProps = {
  title: string
  trigger: string
  children: ReactNode
  wide?: boolean
}

export function GlassModal({
  title,
  trigger,
  children,
  wide = false,
}: GlassModalProps) {
  const dialogRef = useRef<HTMLDialogElement>(null)
  const titleId = useId()

  function openModal() {
    const dialog = dialogRef.current

    if (dialog && !dialog.open) {
      dialog.showModal()
    }
  }

  function closeModal() {
    dialogRef.current?.close()
  }

  function handleBackdropClick(
    event: MouseEvent<HTMLDialogElement>
  ) {
    if (event.target === dialogRef.current) {
      closeModal()
    }
  }

  return (
    <>
      <button
        type="button"
        className="btn btn-primary"
        onClick={openModal}
      >
        {trigger}
      </button>

      <dialog
        ref={dialogRef}
        className={`as-glass-dialog ${
          wide ? 'as-glass-dialog-wide' : ''
        }`}
        aria-labelledby={titleId}
        onClick={handleBackdropClick}
      >
        <div className="as-glass-dialog-head">
          <h2 id={titleId}>{title}</h2>

          <button
            type="button"
            className="as-glass-close"
            aria-label="Close window"
            onClick={closeModal}
          >
            ×
          </button>
        </div>

        <div className="as-glass-dialog-body">
          {children}
        </div>
      </dialog>

      <style>{`
        /* ========================================
           WIDE MODAL — WHITE & BLUE THEME
        ======================================== */

        .as-glass-dialog.as-glass-dialog-wide {
          width: 96vw !important;
          max-width: 1600px !important;
          min-width: 0 !important;
          max-height: 92dvh !important;
          box-sizing: border-box !important;
          padding: 0 !important;
          margin: auto !important;
          overflow: hidden !important;

          background: #ffffff !important;
          color: #1e3a5f !important;
          border: 1px solid #d8e5f3 !important;
          border-radius: 18px !important;
          box-shadow:
            0 24px 80px rgba(24, 62, 115, 0.18) !important;
        }

        /* ========================================
           MODAL HEADER
        ======================================== */

        .as-glass-dialog.as-glass-dialog-wide
        .as-glass-dialog-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          min-height: 68px;
          box-sizing: border-box;
          padding: 16px 24px;

          background: #eff6ff !important;
          border-bottom: 1px solid #d8e5f3 !important;
        }

        .as-glass-dialog.as-glass-dialog-wide
        .as-glass-dialog-head h2 {
          display: block !important;
          visibility: visible !important;
          margin: 0;

          color: #1e3a5f !important;
          font-size: 18px;
          font-weight: 800;
          line-height: 1.3;
        }

        /* ========================================
           CLOSE BUTTON
        ======================================== */

        .as-glass-dialog.as-glass-dialog-wide
        .as-glass-close {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;

          width: 36px;
          height: 36px;
          padding: 0;

          color: #37577b !important;
          background: #ffffff !important;
          border: 1px solid #cad9eb !important;
          border-radius: 9px;

          font-size: 24px;
          line-height: 1;
          cursor: pointer;
          transition:
            background 0.15s ease,
            border-color 0.15s ease;
        }

        .as-glass-dialog.as-glass-dialog-wide
        .as-glass-close:hover {
          background: #eaf2ff !important;
          border-color: #91b8e9 !important;
        }

        /* ========================================
           MODAL BODY
        ======================================== */

        .as-glass-dialog.as-glass-dialog-wide
        .as-glass-dialog-body {
          width: 100%;
          min-width: 0;
          box-sizing: border-box;
          padding: 24px !important;
          max-height: calc(92dvh - 68px);
          overflow-y: auto;
          overflow-x: hidden;

          background: #ffffff !important;
          color: #1e3a5f !important;

          scrollbar-width: thin;
          scrollbar-color: #b9cce4 #ffffff;
        }

        /* ========================================
           BACKDROP
        ======================================== */

        .as-glass-dialog.as-glass-dialog-wide::backdrop {
          background: rgba(25, 47, 77, 0.35);
          backdrop-filter: blur(5px);
        }

        /* ========================================
           RESPONSIVE
        ======================================== */

        @media (max-width: 640px) {
          .as-glass-dialog.as-glass-dialog-wide {
            width: 98vw !important;
            max-height: 96dvh !important;
            border-radius: 12px !important;
          }

          .as-glass-dialog.as-glass-dialog-wide
          .as-glass-dialog-head {
            min-height: 60px;
            padding: 14px 16px;
          }

          .as-glass-dialog.as-glass-dialog-wide
          .as-glass-dialog-head h2 {
            font-size: 16px;
          }

          .as-glass-dialog.as-glass-dialog-wide
          .as-glass-dialog-body {
            padding: 16px !important;
            max-height: calc(96dvh - 60px);
          }
        }
      `}</style>
    </>
  )
}
