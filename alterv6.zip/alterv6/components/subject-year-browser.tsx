'use client'

import { useState } from 'react'
import { GlassModal } from './glass-modal'

type Subject = {
  id: string
  departmentId: string
  year: number
  code: string
  name: string
  description: string
  units: number
  lecture: number
  lab: number
  roomTypeId: string
  facultyId: string
  isActive: boolean
}

type Option = { id: string; name: string }

type Props = {
  subjects: Subject[]
  roomTypes: Option[]
  instructors: Option[]
  qualifications: Record<string, string[]>
  updateAction: (formData: FormData) => void | Promise<void>
}

const yearLabel = (year: number) =>
  `${year}${year === 1 ? 'st' : year === 2 ? 'nd' : year === 3 ? 'rd' : 'th'} Year`

export function SubjectYearBrowser({
  subjects,
  roomTypes,
  instructors,
  qualifications,
  updateAction,
}: Props) {
  const [year, setYear] = useState(1)
  const visible = subjects.filter((subject) => subject.year === year)

  return (
    <section className="panel as-browser">
      <p className="eyebrow">SUBJECT CATALOG</p>
      <h2>Browse Subjects by Year</h2>
      <p className="muted">Select a year level to view and edit its official subjects.</p>

      <div className="as-year-grid" role="group" aria-label="Subject year level">
        {[1, 2, 3, 4].map((value) => (
          <button
            key={value}
            type="button"
            className={`as-year-card ${year === value ? 'as-selected' : ''}`}
            onClick={() => setYear(value)}
            aria-pressed={year === value}
          >
            <strong>{yearLabel(value)}</strong>
            <small>{subjects.filter((subject) => subject.year === value).length} subjects</small>
          </button>
        ))}
      </div>

      <div className="as-browser-controls">
        <span className="muted">{visible.length} subjects in selected year</span>
        <GlassModal key={year} title={`${yearLabel(year)} Subjects`} trigger="View Subjects" wide>
          <div className="as-catalog-modal">
            <div className="as-catalog-heading">
              <div>
                <span className="as-catalog-eyebrow">OFFICIAL BSIT SUBJECT CATALOG</span>
                <p>Update subject details directly in the table. Save each row separately.</p>
              </div>
              <span className="as-catalog-count">
                {visible.length} {visible.length === 1 ? 'subject' : 'subjects'}
              </span>
            </div>

            {visible.length === 0 ? (
              <div className="as-catalog-empty">
                No subjects assigned to this year level. Add a subject using the form on the main page.
              </div>
            ) : (
              <div
                className="as-catalog-scroll"
                role="region"
                aria-label={`${yearLabel(year)} editable subjects`}
                tabIndex={0}
              >
                <table className="as-catalog-table">
                  <thead>
                    <tr>
                      <th scope="col">Code</th>
                      <th scope="col">Subject / Description</th>
                      <th scope="col">Units</th>
                      <th scope="col">Lecture</th>
                      <th scope="col">Lab</th>
                      <th scope="col">Year Level</th>
                      <th scope="col">Room Type</th>
                      <th scope="col">Instructor</th>
                      <th scope="col">Status</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visible.map((subject) => {
                      const formId = `as-edit-${subject.id}`
                      const eligible = new Set(qualifications[subject.id] ?? [])
                      const allowedInstructors = instructors.filter((instructor) => eligible.has(instructor.id))
                      const assignedInstructor = instructors.find((instructor) => instructor.id === subject.facultyId)
                      const currentInstructorMissing = Boolean(subject.facultyId) &&
                        !allowedInstructors.some((instructor) => instructor.id === subject.facultyId)

                      return (
                        <tr key={subject.id}>
                          <td>
                            <input form={formId} name="code" aria-label={`Code for ${subject.code}`}
                              defaultValue={subject.code} required className="as-catalog-input as-code-input" />
                          </td>
                          <td>
                            <div className="as-name-cell">
                              <input form={formId} name="subject_name" aria-label={`Subject name for ${subject.code}`}
                                defaultValue={subject.name} required className="as-catalog-input as-name-input" />
                              <input form={formId} name="description" aria-label={`Description for ${subject.code}`}
                                defaultValue={subject.description} placeholder="No description"
                                className="as-catalog-input as-description-input" />
                            </div>
                          </td>
                          <td>
                            <input form={formId} name="units" aria-label={`Units for ${subject.code}`}
                              type="number" min="0" max="20" step="0.5" defaultValue={subject.units}
                              required className="as-catalog-input as-number-input" />
                          </td>
                          <td>
                            <input form={formId} name="lecture_hours" aria-label={`Lecture hours for ${subject.code}`}
                              type="number" min="0" max="40" step="0.5" defaultValue={subject.lecture}
                              required className="as-catalog-input as-number-input" />
                          </td>
                          <td>
                            <input form={formId} name="lab_hours" aria-label={`Lab hours for ${subject.code}`}
                              type="number" min="0" max="40" step="0.5" defaultValue={subject.lab}
                              required className="as-catalog-input as-number-input" />
                          </td>
                          <td>
                            <select form={formId} name="default_year_level" aria-label={`Year level for ${subject.code}`}
                              defaultValue={String(subject.year)} required className="as-catalog-select">
                              {[1, 2, 3, 4].map((value) => (
                                <option key={value} value={value}>{yearLabel(value)}</option>
                              ))}
                            </select>
                          </td>
                          <td>
                            <select form={formId} name="default_room_type_id" aria-label={`Room type for ${subject.code}`}
                              defaultValue={subject.roomTypeId} className="as-catalog-select">
                              <option value="">Any Room</option>
                              {roomTypes.map((room) => <option key={room.id} value={room.id}>{room.name}</option>)}
                            </select>
                          </td>
                          <td>
                            <select form={formId} name="default_faculty_id" aria-label={`Instructor for ${subject.code}`}
                              defaultValue={subject.facultyId} className="as-catalog-select">
                              <option value="">Auto assign</option>
                              {currentInstructorMissing && (
                                <option value={subject.facultyId} disabled>
                                  {assignedInstructor?.name ?? 'Previously assigned instructor'} (not qualified/approved)
                                </option>
                              )}
                              {allowedInstructors.map((instructor) => (
                                <option key={instructor.id} value={instructor.id}>{instructor.name}</option>
                              ))}
                            </select>
                            {allowedInstructors.length === 0 && (
                              <small className="as-instructor-note">No qualified instructor</small>
                            )}
                          </td>
                          <td>
                            <span className={`as-catalog-status ${subject.isActive ? 'as-active' : 'as-inactive'}`}>
                              {subject.isActive ? 'Active' : 'Inactive'}
                            </span>
                          </td>
                          <td>
                            <form id={formId} action={updateAction}>
                              <input type="hidden" name="subject_id" value={subject.id} />
                              <input type="hidden" name="department_id" value={subject.departmentId} />
                              <button type="submit" className="as-catalog-save">Save</button>
                            </form>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
            <div className="as-catalog-footer">
              <span>Scroll sideways on smaller screens to see all columns.</span>
              <span>Each Save updates one subject.</span>
            </div>
          </div>

          <style>{`
            .as-glass-dialog-wide .as-catalog-modal {
              width: 100%; min-width: 0; color: #213a58;
              font-family: inherit;
            }
            .as-glass-dialog-wide .as-catalog-heading {
              display: flex; justify-content: space-between; align-items: center;
              gap: 14px; flex-wrap: wrap; margin-bottom: 14px;
            }
            .as-glass-dialog-wide .as-catalog-eyebrow {
              display: block; color: #1e63ad; font-size: 11px; font-weight: 800;
              letter-spacing: .09em; margin-bottom: 5px;
            }
            .as-glass-dialog-wide .as-catalog-heading p {
              color: #60758e; font-size: 12px; line-height: 1.5; margin: 0;
            }
            .as-glass-dialog-wide .as-catalog-count {
              display: inline-flex; align-items: center; flex-shrink: 0;
              background: #edf5ff; color: #1b5ca5; border: 1px solid #cce0fa;
              border-radius: 999px; padding: 7px 12px; font-size: 12px; font-weight: 800;
            }
            .as-glass-dialog-wide .as-catalog-scroll {
              width: 100%; max-width: 100%; overflow-x: auto; overflow-y: auto;
              max-height: min(62dvh, 660px); border: 1px solid #d7e3f1;
              border-radius: 10px; background: #fff; scrollbar-width: thin;
              scrollbar-color: #adc6e3 #f2f7ff;
            }
            .as-glass-dialog-wide .as-catalog-table {
              width: 100%; min-width: 1340px; border-collapse: separate;
              border-spacing: 0; table-layout: fixed; color: #213a58;
            }
            .as-glass-dialog-wide .as-catalog-table th {
              position: sticky; top: 0; z-index: 2; padding: 12px 9px;
              text-align: left; white-space: nowrap; color: #294e7a;
              background: #eaf3ff; border-bottom: 1px solid #cbdff5;
              font-size: 10px; font-weight: 800; letter-spacing: .025em;
            }
            .as-glass-dialog-wide .as-catalog-table td {
              padding: 10px 8px; vertical-align: middle; color: #263e5b;
              background: #fff; border-bottom: 1px solid #e4edf7;
            }
            .as-glass-dialog-wide .as-catalog-table tbody tr:nth-child(even) td {
              background: #f8fbff;
            }
            .as-glass-dialog-wide .as-catalog-table tbody tr:hover td {
              background: #eef6ff;
            }
            .as-glass-dialog-wide .as-catalog-table tbody tr:last-child td {
              border-bottom: 0;
            }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(1) { width: 100px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(2) { width: 245px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(3),
            .as-glass-dialog-wide .as-catalog-table th:nth-child(4),
            .as-glass-dialog-wide .as-catalog-table th:nth-child(5) { width: 78px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(6) { width: 120px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(7) { width: 145px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(8) { width: 185px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(9) { width: 92px; }
            .as-glass-dialog-wide .as-catalog-table th:nth-child(10) { width: 92px; }
            .as-glass-dialog-wide .as-catalog-input,
            .as-glass-dialog-wide .as-catalog-select {
              width: 100%; min-width: 0; min-height: 36px; box-sizing: border-box;
              border: 1px solid #d2dfef; border-radius: 7px; padding: 7px 9px;
              background: #fff; color: #1e3552; font: inherit; font-size: 12px;
              outline: none; box-shadow: none; color-scheme: light;
            }
            .as-glass-dialog-wide .as-catalog-input:focus,
            .as-glass-dialog-wide .as-catalog-select:focus {
              border-color: #397fda; box-shadow: 0 0 0 3px rgba(57,127,218,.13);
            }
            .as-glass-dialog-wide .as-name-cell {
              display: flex; flex-direction: column; gap: 5px;
            }
            .as-glass-dialog-wide .as-code-input,
            .as-glass-dialog-wide .as-name-input { font-weight: 700; }
            .as-glass-dialog-wide .as-description-input { font-size: 11px; color: #5c718a; }
            .as-glass-dialog-wide .as-number-input { text-align: center; }
            .as-glass-dialog-wide .as-instructor-note {
              display: block; margin-top: 5px; color: #a35c11;
              font-size: 10px; font-weight: 600;
            }
            .as-glass-dialog-wide .as-catalog-status {
              display: inline-flex; align-items: center; border-radius: 999px;
              padding: 6px 9px; font-size: 10px; font-weight: 800;
            }
            .as-glass-dialog-wide .as-active { color: #08764f; background: #e2f7ec; }
            .as-glass-dialog-wide .as-inactive { color: #9c5a13; background: #fff0d9; }
            .as-glass-dialog-wide .as-catalog-save {
              width: 100%; min-height: 36px; border: 1px solid #2563eb;
              border-radius: 7px; padding: 7px 10px; color: #fff;
              background: #2563eb; font: inherit; font-size: 12px;
              font-weight: 800; cursor: pointer;
            }
            .as-glass-dialog-wide .as-catalog-save:hover { background: #1d4ed8; }
            .as-glass-dialog-wide .as-catalog-save:focus-visible {
              outline: 3px solid #93c5fd; outline-offset: 2px;
            }
            .as-glass-dialog-wide .as-catalog-footer {
              display: flex; justify-content: space-between; flex-wrap: wrap;
              gap: 8px; margin-top: 10px; color: #71849a; font-size: 11px;
            }
            .as-glass-dialog-wide .as-catalog-empty {
              padding: 28px 16px; text-align: center; border: 1px dashed #b8d0ea;
              border-radius: 10px; background: #f7fbff; color: #4d6481;
            }
            @media (max-width: 640px) {
              .as-glass-dialog-wide .as-catalog-scroll { max-height: 65dvh; }
              .as-glass-dialog-wide .as-catalog-table td { padding: 8px 6px; }
            }
          `}</style>
        </GlassModal>
      </div>
    </section>
  )
}
