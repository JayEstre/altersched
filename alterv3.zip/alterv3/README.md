# AlterSched

AlterSched is the CCTC academic scheduling system for three staff roles: Administrator, Department Scheduler, and Instructor. Students do not create accounts; they receive a read-only published schedule through the public QR/link generated during publication.

## Workflow
1. Instructor registers and waits for Administrator approval.
2. Administrator maintains Subjects, Rooms/Labs, School Year/Semester, Instructor records and qualifications.
3. Department Scheduler prepares scheduling inputs and runs AI Schedule Automation.
4. The engine assigns subject/block sessions to qualified instructors, compatible rooms, days and times while enforcing hard conflict rules and applying timetable optimization scoring.
5. Scheduler reviews the editable Preview Table or Timetable view, resolves conflicts, and saves only a conflict-free draft.
6. Scheduler publishes the schedule. Affected instructors receive in-app notifications and email when email delivery is configured.
7. Publication generates a revocable public schedule token/QR for students.
8. Schedules can be exported to Excel/CSV.

## Roles
- `super_admin` — Administrator
- `department_scheduler` — Department Scheduler
- `faculty` — Instructor

## Local setup
```bash
npm install
npm run dev
```

Configure Supabase environment variables before running the app. For email notifications, configure `RESEND_API_KEY` and `ALTERSCHED_EMAIL_FROM`.

## Important
The old Student portal and active Curricula workflow were removed from the application source. Legacy database tables may remain for migration safety; do not drop production tables without a verified database migration/backup.
