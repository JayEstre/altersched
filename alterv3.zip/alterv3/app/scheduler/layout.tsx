import PortalLayout from "@/components/portal-layout";
import { requireRole } from "@/lib/auth/require-role";

const navigation = [
  {
    type: "item" as const,
    href: "/scheduler/dashboard",
    label: "Dashboard",
  },

  // =====================================================
  // SCHEDULING
  // =====================================================

  {
    type: "group" as const,
    label: "SCHEDULING",
  },

  {
    type: "item" as const,
    href: "/scheduler/schedule-builder",
    label: "Schedule Builder",
  },

  {
    type: "item" as const,
    href: "/scheduler/schedules",
    label: "Schedules & Publish",
  },

  {
    type: "item" as const,
    href: "/scheduler/class-offerings",
    label: "Scheduling Inputs",
  },

  // =====================================================
  // RESOURCES
  // =====================================================

  {
    type: "group" as const,
    label: "RESOURCES",
  },

  {
    type: "item" as const,
    href: "/scheduler/faculty",
    label: "Instructors",
  },

  {
    type: "item" as const,
    href: "/scheduler/rooms",
    label: "Rooms",
  },

  // =====================================================
  // PERSONAL
  // =====================================================

  {
    type: "group" as const,
    label: "PERSONAL",
  },

  {
    type: "item" as const,
    href: "/scheduler/my-schedule",
    label: "My Schedule",
  },

  {
    type: "item" as const,
    href: "/scheduler/change-requests",
    label: "Change Requests",
  },

  // =====================================================
  // SYSTEM
  // =====================================================

  {
    type: "group" as const,
    label: "SYSTEM",
  },

  {
    type: "item" as const,
    href: "/scheduler/notifications",
    label: "Notifications",
  },

  {
    type: "item" as const,
    href: "/scheduler/profile",
    label: "Profile",
  },
];

export default async function Layout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { user, profile } =
    await requireRole([
      "department_scheduler",
    ]);

  return (
    <PortalLayout
      title="Department Scheduler"
      subtitle="SCHEDULER PORTAL"
      name={
        profile.full_name ||
        "Department Scheduler"
      }
      email={user.email}
      navigation={navigation}
    >
      {children}
    </PortalLayout>
  );
}