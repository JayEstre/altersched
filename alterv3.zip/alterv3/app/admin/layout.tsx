import PortalLayout from '@/components/portal-layout'
import { requireRole } from '@/lib/auth/require-role'

const navigation = [
  { href: '/admin/dashboard', label: 'Dashboard' },
  { href: '/admin/users', label: 'Instructor Approvals' },

  // Master scheduling data
  { href: '/admin/subjects', label: 'Subjects' },
  { href: '/admin/curriculum', label: 'Curriculum' },
  { href: '/admin/rooms', label: 'Rooms & Labs' },
  { href: '/admin/academic', label: 'School Year & Semester' },
  { href: '/admin/faculty', label: 'Instructors' },

  // Bulk reference-data import and schedule/data export
  { href: '/admin/import-export', label: 'Import / Export' },

  { href: '/admin/settings', label: 'Settings' },
]

export default async function Layout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, profile } = await requireRole(['super_admin'])

  return (
    <PortalLayout
      title="Administrator"
      subtitle="ADMIN PORTAL"
      name={profile.full_name || 'Administrator'}
      email={user.email}
      navigation={navigation}
    >
      {children}
    </PortalLayout>
  )
}