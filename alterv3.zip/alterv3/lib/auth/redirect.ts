// 'student' remains a legacy database value only; V2 exposes three staff roles.
export type AlterSchedRole = 'super_admin' | 'department_scheduler' | 'faculty' | 'student'
export type AccountStatus = 'pending' | 'approved' | 'rejected' | 'suspended' | 'inactive'

export function destinationFor(role: string, status: AccountStatus) {
  if (status !== 'approved') return '/pending-approval'
  if (role === 'super_admin') return '/admin/dashboard'
  if (role === 'department_scheduler') return '/scheduler/dashboard'
  if (role === 'faculty') return '/faculty/dashboard'
  return '/login?error=role_not_supported'
}
